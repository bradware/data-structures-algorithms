import java.util.List;
import java.util.Map;


public class AdjacencyList {
	
	private Map<Vertex, List<Pair>> adjacencyList;
	
	/**
	 * A list of edges will be passed in and the adjacency list will be prepared to use
	 */
	public AdjacencyList(List<Edge> edges) {
		// TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * @param vexter a vertex
	 * @return	a list of pair i.e. vertices and weights adjacent to vertex
	 */
	public List<Pair> adjacencies(Vertex vertex) {
		// TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	/*
	 * Getters and setters
	 */
	
	public Map<Vertex, List<Pair>> getAdjacencyList() {
		// TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public void setAdjacencyList(Map<Vertex, List<Pair>> adjacencyList) {
		// TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}
}
