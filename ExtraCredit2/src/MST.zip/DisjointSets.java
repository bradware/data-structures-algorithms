import java.util.Map;
import java.util.Set;


public class DisjointSets<T> {
	
	private Map<T, Node<T>> map;
	
	/**
	 * Takes in a set of generic type objects. 
	 * Here you need to wrap each object T in a Node and then add the pair of object T and its resulting 
	 * node to a HashMap.
	 * Conceptually you can think of this step as making each node to be its own disjoint set. 
	 * Then whenever you need you can use merge function to merge these little disjoint sets.
	 */
	public DisjointSets(Set<T> set) {
		//TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	/**
	 * In this method you need to do path compression for object o:
	 * 1) wrap the object o in a Node
	 * 2) find the root of the disjoint set that o is attached to call it root
	 * 3) then make the root be the parent of o
	 * 
	 * @param o 	an object of type T whose root is to be found
	 * @return 		the root of the vertex taken in
	 */
	public T findParent(T o) {
		//TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	/**
	 * points the root of the firstObject to the root of the secondObject.
	 * If they already have the same root don't do anything.
	 *  
	 * @param firstObject an object of type T who is to be merged with parameter secondObject
	 * @param firstObject an object of type T who is to be merged with parameter firstObject
	 */
	public void merge(T firstObject, T secondObject) {
		//TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");			
	}
	

	/**
	 * Basic node class for use with DisjointSet
	 */
	private class Node<T> {

		private T data;
		private Node<T> parent;

		/**
		 * set the data to be the given data and set parent to null
		 * @param data
		 */
		public Node(T data) {
			// TODO implement this!
			throw new UnsupportedOperationException("Not implemented yet");
		}

		/**
		 * set the data and parent to the given values
		 * @param data
		 * @param parent
		 */
		public Node(T data, Node<T> parent) {
			// TODO implement this!
			throw new UnsupportedOperationException("Not implemented yet");
		}

		/*implement all the setters and getters below*/
		public void setData(T data) {
			// TODO implement this!
			throw new UnsupportedOperationException("Not implemented yet");
		}

		public void setParent(Node<T> parent) {
			// TODO implement this!
			throw new UnsupportedOperationException("Not implemented yet");
		}

		public T getData() {
			// TODO implement this!
			throw new UnsupportedOperationException("Not implemented yet");
		}

		public Node<T> getParent() {
			// TODO implement this!
			throw new UnsupportedOperationException("Not implemented yet");
		}
	}

}