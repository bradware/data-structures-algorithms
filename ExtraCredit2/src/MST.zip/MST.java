import java.util.Collection;
import java.util.List;

public class MST {

	/**
	 * Find MST using Kruskal's algorithm. Follow the instructions in the pdf.
	 * 
	 * @param edges	the edge list that represents the graph
	 * @return 		a collection of edges that represent the MST
	 */
	public static Collection<Edge> kruskals(List<Edge> edges) {
		// TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * Implement Prim's algo-rhythm!
	 * 
	 * @param start	the starting vertex of the MST, you are guaranteed that
	 * 				it is contained in the AdjacencyList
	 * @param graph	the adjacency list that represents the graph. You need to find MST for this graph 
	 * @return 		a collection of edges that represent the MST of the graph
	 */
	public static Collection<Edge> prims(Vertex start, AdjacencyList graph) {
		// TODO implement this!
		throw new UnsupportedOperationException("Not implemented yet");
	}
}
